# UM PDF User Submitted data
PDF with Submitted User Registration Data.

## Installation

1. Download zip file. 
2. Unzip and upload as a plugin to Wordpress the zip file um-pdf-submitted.zip
3. Activate the plugin
4. Modify the email template you want to have a link to the user submitted PDF file and add the placeholder {pdf_submitted_link}
5. Add to the email template page your Header and Footer text for the PDF page (may include HTML)
6. The meta-key used for storing the PDF file name is: um_pdf_submitted
7. Location for storing the PDF file is the users uploads folder.
