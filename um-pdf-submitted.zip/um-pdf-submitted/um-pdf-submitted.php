<?php
/**
 * Plugin Name:     Ultimate Member - PDF User Submitted data
 * Description:     Ultimate Member - PDF with Submitted User Registration Data.
 * Version:         1.0.0
 * Requires PHP:    7.4
 * Author:          Miss Veronica
 * License:         GPL v2 or later
 * License URI:     https://www.gnu.org/licenses/gpl-2.0.html
 * Author URI:      https://github.com/MissVeronica
 * Text Domain:     ultimate-member
 * Domain Path:     /languages
 * UM version:      2.5.01
 * Font             http://www.onlinewebfonts.com
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'UM' ) ) return;

use Dompdf\Dompdf;

class UM_PDF_Submitted {

    function __construct( ) {

        define( 'um_pdf_submitted_path', plugin_dir_path( __FILE__ ) );
        add_filter( 'um_email_send_message_content', array( $this, 'um_email_send_message_content_custom' ), 10, 3);
    }

    function um_email_send_message_content_custom( $message, $slug, $args ) {

        if( strpos( $message, '{pdf_submitted_link}' ) > 0 ) {

            $file = $this->um_user_submitted_registration_formatted_custom();

            $pdf = UM()->uploader()->get_upload_base_url() . um_user( 'ID' ) . '/' . $file;
            $link = '<a href="' . esc_url( $pdf ) . '">' . __( 'PDF file', 'ultimate-member' ) . '</a>'; 
            $message = str_replace( '{pdf_submitted_link}', $link, $message );
        }

        return $message;
    }

    function um_user_submitted_registration_formatted_custom() {

        require_once( um_pdf_submitted_path . "dompdf/autoload.inc.php" );

        $dompdf = new Dompdf();
        $options = $dompdf->getOptions();
        $options->setDefaultFont( 'Courier' );
        $dompdf->setOptions( $options );

        $css = file_get_contents( um_path . 'includes/admin/assets/css/um-admin-modal.css' );
        $html  = "<!DOCTYPE html><html><style type='text/css'>" . $css . "</style><body><h1>Ultimate Member Registration Data</h1>";
        $html .= um_user_submitted_registration_formatted( true );
        $html .= '<h2>End of submitted data</h2></body></html>';

        $dompdf->load_html( $html );
        $dompdf->render();
        $output = $dompdf->output();
        
        $hashed = hash('ripemd160', time() . mt_rand( 10, 1000 ) );
        $file = 'file_submitted_' . $hashed . '.pdf';
        $status = file_put_contents( WP_CONTENT_DIR . '/uploads/ultimatemember/' . um_user( 'ID' ) . '/' . $file, $output );
         
        if( $status ) update_user_meta( um_user( 'ID' ), "um_pdf_submitted", $file );

        return $file;
    }
}

new UM_PDF_Submitted();