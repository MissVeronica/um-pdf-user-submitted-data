<?php
/**
 * Plugin Name:     Ultimate Member - PDF User Submitted data
 * Description:     Ultimate Member - PDF with Submitted User Registration Data.
 * Version:         1.0.0
 * Requires PHP:    7.4
 * Author:          Miss Veronica
 * License:         GPL v2 or later
 * License URI:     https://www.gnu.org/licenses/gpl-2.0.html
 * Author URI:      https://github.com/MissVeronica
 * Text Domain:     ultimate-member
 * Domain Path:     /languages
 * UM version:      2.5.0
 * Font             http://www.onlinewebfonts.com
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! class_exists( 'UM' ) ) return;

use Dompdf\Dompdf;

class UM_PDF_Submitted {

    function __construct( ) {

        define( 'um_pdf_submitted_path', plugin_dir_path( __FILE__ ) );
        add_filter( 'um_email_send_message_content',          array( $this, 'um_email_send_message_content_custom' ), 10, 3);
        add_filter( 'um_admin_settings_email_section_fields', array( $this, 'um_admin_settings_email_section_fields_custom' ), 10, 2 );

    }

    function um_email_send_message_content_custom( $message, $slug, $args ) {

        if( strpos( $message, '{pdf_submitted_link}' ) > 0 ) {

            $file = $this->um_user_submitted_registration_formatted_custom( $slug );

            $pdf = UM()->uploader()->get_upload_base_url() . um_user( 'ID' ) . '/' . $file;
            $link = '<a href="' . esc_url( $pdf ) . '">' . UM()->options()->get( $slug . '_pdf_link_text' ) . '</a>'; 
            $message = str_replace( '{pdf_submitted_link}', $link, $message );
        }

        return $message;
    }

    function um_user_submitted_registration_formatted_custom( $slug ) {

        require_once( um_pdf_submitted_path . "dompdf/autoload.inc.php" );

        $dompdf = new Dompdf();
        $options = $dompdf->getOptions();
        $options->setDefaultFont( UM()->options()->get( $slug . '_pdf_font' ) );
        $dompdf->setOptions( $options );

        $css = file_get_contents( um_path . 'includes/admin/assets/css/um-admin-modal.css' );

        $html  = "<!DOCTYPE html><html><style type='text/css'>" . $css . "</style><body>";
        $html .= '<div>' . UM()->options()->get( $slug . '_pdf_header' ) . '</div>';
        $html .= um_user_submitted_registration_formatted( true );
        $html .= '<div>' . UM()->options()->get( $slug . '_pdf_footer' ) . '</div>';
        $html .= '</body></html>';

        $dompdf->load_html( $html );
        $dompdf->render();
        $output = $dompdf->output();
        
        $hashed = hash('ripemd160', time() . mt_rand( 10, 1000 ) );
        $file = 'file_submitted_' . $hashed . '.pdf';
        $status = file_put_contents( WP_CONTENT_DIR . '/uploads/ultimatemember/' . um_user( 'ID' ) . '/' . $file, $output );
         
        if( $status ) update_user_meta( um_user( 'ID' ), "um_pdf_submitted", $file );

        return $file;
    }

    function um_admin_settings_email_section_fields_custom( $section_fields, $email_key ) {

        $section_fields[] = array(
                'id'            => $email_key . '_pdf_header',
                'type'          => 'text',
                'label'         => __( 'PDF Header text incl HTML', 'ultimate-member' ),
                'conditional'   => array( $email_key . '_on', '=', 1 ),
                'tooltip'       => __( 'PDF with Submitted User Registration Data', 'ultimate-member' )
                );
    
        $section_fields[] = array(
                'id'            => $email_key . '_pdf_footer',
                'type'          => 'text',
                'label'         => __( 'PDF Footer text incl HTML', 'ultimate-member' ),
                'conditional'   => array( $email_key . '_on', '=', 1 ),
                'tooltip'       => __( 'PDF with Submitted User Registration Data', 'ultimate-member' )
                );

        $section_fields[] = array(
                'id'            => $email_key . '_pdf_link_text',
                'type'          => 'text',
                'label'         => __( 'PDF URL link text', 'ultimate-member' ),
                'conditional'   => array( $email_key . '_on', '=', 1 ),
                'tooltip'       => __( 'PDF with Submitted User Registration Data', 'ultimate-member' )
                );
            
        $section_fields[] = array(
                'id'      => $email_key . '_pdf_font',
                'type'    => 'select',
                'size'    => 'small',
                'label'   => __( 'Select font for the PDF file', 'ultimate-member' ),
                'tooltip' => __( 'PDF with Submitted User Registration Data', 'ultimate-member' ),
                'options' => array(
                    'Courier'   => __( 'Courier', 'ultimate-member' ),
                    'DejaVu'    => __( 'DejaVu', 'ultimate-member' ),
                    'Helvetica' => __( 'Helvetica', 'ultimate-member' ),
                    'Times'     => __( 'Times', 'ultimate-member' ))
                );

        return $section_fields;
    }
}

new UM_PDF_Submitted();